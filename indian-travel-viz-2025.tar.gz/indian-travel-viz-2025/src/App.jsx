import IndianTravelViz2025 from './components/IndianTravelViz2025'

function App() {
  return <IndianTravelViz2025 />
}

export default App
